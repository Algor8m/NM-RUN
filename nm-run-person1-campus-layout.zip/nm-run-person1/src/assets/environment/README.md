# Environment assets (Person 1)

Stage 1 environment geometry is generated procedurally inside `src/track/TrackBuilder.js`, so this folder intentionally contains no duplicate helpers yet. If environment generation is split out in Stage 2, keep helper exports deterministic and preserve the track module's public API.
